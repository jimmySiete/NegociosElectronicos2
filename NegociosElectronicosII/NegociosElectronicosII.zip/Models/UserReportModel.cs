﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NegociosElectronicosII.Models
{
    public class UsuarioReporteModel
    {
        public string Usuario { get; set; }
        public Decimal Total { get; set; }
    }
}